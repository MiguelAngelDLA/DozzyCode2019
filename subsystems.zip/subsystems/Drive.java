package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Drive {

    private final boolean fourWD = true; // Bandera que indica si se usarán 2 o 4 motores para el drive
    private DcMotor leftDrive;
    private DcMotor rightDrive;
    private DcMotor leftDrive2;
    private DcMotor rightDrive2;
    private double lastTurnPower = 0, lastPower = 0;
    private static final double maxGain = 0.1;
    /**
     * Co nstructor de la clase Drive
     * @param hardwareMap Instancia del mapa del hardware que utilizará el robot.
     */
    public Drive(HardwareMap hardwareMap){
        leftDrive = hardwareMap.get(DcMotor.class, "m0");
        rightDrive = hardwareMap.get(DcMotor.class, "m1");
        if(fourWD){
            leftDrive2 = hardwareMap.get(DcMotor.class, "m2");
            rightDrive2 = hardwareMap.get(DcMotor.class, "m3");
        }
        init();
    }

    /**
     * Define el modo en el que estarán usándose todos los motores del sistema.
     * Comunmente usado para reiniciar los encoders y después utilizarlos.
     * @param runMode DcMotor.RunMode
     */
    public void setMode(DcMotor.RunMode runMode){
        leftDrive.setMode(runMode);
        rightDrive.setMode(runMode);
        if(fourWD){
            leftDrive2.setMode(runMode);
            rightDrive2.setMode(runMode);
        }
    }

    public void setLeftTargetPosition(int targetPosition){
        leftDrive.setTargetPosition(targetPosition);
        if(fourWD)
            leftDrive2.setTargetPosition(targetPosition);
    }

    public void setRightTargetPosition(int targetPosition){
        rightDrive.setTargetPosition(targetPosition);
        if(fourWD)
            rightDrive2.setTargetPosition(targetPosition);
    }

    public void setLeftPower(double power){
        power = power > 1.0 ? 1 : power < -1.0 ? -1 : power;
        leftDrive.setPower(power);
        if(fourWD)
            leftDrive2.setPower(power);
    }

    public void setRightPower(double power){
        power = power > 1.0 ? 1 : power < -1.0 ? -1 : power;
        rightDrive.setPower(power);
        if(fourWD)
            rightDrive2.setPower(power);
    }

    public void init(){
        leftDrive.setDirection(DcMotor.Direction.FORWARD);
        rightDrive.setDirection(DcMotor.Direction.REVERSE);

        if(fourWD){
            leftDrive2.setDirection(DcMotor.Direction.FORWARD);
            rightDrive2.setDirection(DcMotor.Direction.REVERSE);
        }

        setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    public void arcadeDrive(double move, double rotate){
        setLeftPower(move + rotate);
        setRightPower(move - rotate);
        lastPower = move;
        lastTurnPower = rotate;
    }

    public void tweenedDrive(double movePower, double turnPower){
        if(Math.abs(turnPower - lastTurnPower) > maxGain)
            turnPower = turnPower >= lastTurnPower ?
                    lastTurnPower + maxGain : lastTurnPower - maxGain;
        if(Math.abs(movePower - lastPower) > maxGain)
            movePower = movePower >= lastPower ?
                    lastPower + maxGain : lastPower - maxGain;
        arcadeDrive(movePower, turnPower);
    }

    public double getLeftSpeed(){ return leftDrive.getPower(); }

    public double getRightSpeed(){ return rightDrive.getPower(); }

    public int getLeftDistance(){ return leftDrive.getCurrentPosition(); }

    public int getRightDistance(){ return rightDrive.getCurrentPosition(); }

    public DcMotor getLeftDrive(){ return leftDrive; }

    public DcMotor getRightDrive(){ return rightDrive; }

}
