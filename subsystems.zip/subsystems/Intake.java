package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.CRServo;

public class Intake {

    private CRServo s0;
    private CRServo s1;

    public Intake(HardwareMap hardwareMap) {
        s0 = hardwareMap.get(CRServo.class, "s0");
        s1 = hardwareMap.get(CRServo.class, "s1");

        init();
    }

    public void init() {
        s0.setDirection(CRServo.Direction.REVERSE);
        s1.setDirection(CRServo.Direction.REVERSE);
    }

    public void set(double power) {
        s0.setPower(power);
        s1.setPower(power == 0 ?  0 : -power);
    }

}