package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Arm {

    private DcMotor arm0;
    private DcMotor arm1;

    public Arm(HardwareMap hardwareMap) {
        arm0 = hardwareMap.get(DcMotor.class, "arm0");
        arm1 = hardwareMap.get(DcMotor.class, "arm1");

        init();
    }

    public void init() {
        arm0.setDirection(DcMotor.Direction.FORWARD);
        arm1.setDirection(DcMotorSimple.Direction.REVERSE);
        setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    public void setMode(DcMotor.RunMode runMode){
        arm0.setMode(runMode);
        arm1.setMode(runMode);
    }

    public void set(double power) {
        arm0.setPower(power);
        arm1.setPower(power);
    }

    public double getSpeed() {
        return arm0.getPower();
    }

    public double getDistance() {
        return arm0.getCurrentPosition();
    }
}