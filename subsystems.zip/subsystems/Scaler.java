package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Scaler {

    private DcMotor scaler;

    public Scaler(HardwareMap hardwareMap) {
        scaler = hardwareMap.get(DcMotor.class, "scaler");

        init();
    }

    public void init() {
        scaler.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        scaler.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    public void set(double power) {
       scaler.setPower(power);
    }
}

