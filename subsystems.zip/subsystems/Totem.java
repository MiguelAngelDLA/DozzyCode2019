package org.firstinspires.ftc.teamcode.subsystems;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class Totem {

    private Servo totem;

    public Totem(HardwareMap hardwareMap) {
        totem = hardwareMap.get(Servo.class, "totem");
        init();
    }

    public void init() {
        totem.setPosition(0.65);
    }


    public void set(double position) {
        totem.setPosition(position);
    }
}
